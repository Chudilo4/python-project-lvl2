# file<check_dict_value.py


from package.include.check_things_value import check_things_value


def check_dict_value(value, indent):
    result = ''
    indent += '    '
    if type(value) is dict:
        result = '{'
        for k, v in value.items():
            result += '\n' + f'{indent}  {k}: {check_dict_value(v, indent)}'
        result += '\n' + f'{indent[:-2]}}}'
    else:
        result = check_things_value(value)
    return result
