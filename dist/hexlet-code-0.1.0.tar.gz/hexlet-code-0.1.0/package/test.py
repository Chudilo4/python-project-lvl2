# file<test.py>


import json




diff2 = generate_diff(json.load(open('file3.json')), json.load(open('file4.json')))



print(render(diff2))

#for i in value:
#    if i[2] == 'del':
#        txt += '\n' + f'{ident}{delet_step}{i[0]}: {i[1]}'
#    elif i[2] == 'not change':
#        txt += '\n' + f'{ident}{step}{i[0]}: {i[1]}'
#    elif i[2] == 'add':
#        if type(i[3]) is dict:
#            depth += 1
#            txt += '\n' + f'{ident}{step}{i[0]}: {render(i[3], depth)}'
#        txt += '\n' + f'{ident}{add_step}{i[0]}: {i[3]}'
#    elif i[2] == 'changed':
#        txt += '\n' + f'{ident}{delet_step}{i[0]}: {i[1]}'
#        txt += '\n' + f'{ident}{add_step}{i[0]}: {i[3]}'
#    elif i[2] == 'have children':
#        depth += 1
#        txt += '\n' + f'{ident}{step}{i[0]}: {render(i[4], depth)}'
#txt += '\n}'